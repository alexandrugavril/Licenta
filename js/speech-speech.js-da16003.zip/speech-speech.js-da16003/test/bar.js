function bar(){
  console.log("bar");
}