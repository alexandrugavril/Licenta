function foo(){
  console.log("foo");
}