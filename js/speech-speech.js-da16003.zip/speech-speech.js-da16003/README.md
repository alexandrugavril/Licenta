This codebase has been deprecated as Speech.is retools for a different technology.  You can find more information at our [blog](http://speech-is.tumblr.com/post/115059190532/pivot).
